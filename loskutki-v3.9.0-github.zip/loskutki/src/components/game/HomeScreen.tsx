'use client';

import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import {
  BookOpen,
  BarChart3,
  UserRoundPlus,
  Settings2,
  ShieldCheck,
  Play,
  CalendarDays,
  Sparkles,
  RotateCcw,
  Users,
  Zap,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { BOT_PERSONAS, PATCHES, type BotLevel } from '@/lib/game/constants';
import { orientationCells } from './PatchGlyph';
import { orientationsFor } from '@/lib/game/placement';
import { BotAvatar, GlyphDirect, Portrait } from './MarketRow';
import { PatchGlyph } from './PatchGlyph';
import { avatarUrl } from '@/lib/avatars';
import {
  ACHIEVEMENTS,
  loadStore,
  saveStore,
  subscribeStore,
  getStoreSnapshot,
  getStoreServerSnapshot,
  todayKey,
  type StatsStore,
} from '@/lib/storage';
import { dailyNumber } from '@/lib/game/rng';
import { useOnline } from '@/lib/useOnline';
import { APP_VERSION } from '@/lib/version';
import { useFriends } from '@/lib/friends';
import { formatFriendCode, mpJoin, mpListRooms, mpOnRooms, mpWsEnabled, type MpSession } from '@/lib/net';
import { type OpenRoomInfo } from '@/lib/ws';
import { FriendsDialog } from './FriendsDialog';
import { ConfirmDialog } from './ConfirmDialog';
import {
  achDesc,
  achTitle,
  personaDifficulty,
  personaName,
  personaTitle,
  t,
  useDocumentTitle,
  useLang,
  type Lang,
} from '@/lib/i18n';
import { sound } from '@/lib/sound';
import { useToast } from '@/hooks/use-toast';
import { MiniQuilt } from './QuiltBoard';
import type { GameState } from '@/lib/game/types';

/** Раскладка лого — как на иконке игры: реальные фигурки, упакованные
 *  без дыр в полотно 6×6 (сгенерирована scripts/make_icon.ts) */
const LOGO_PACK: ReadonlyArray<{ id: number; o: number; r: number; c: number }> = [
  { id: 14, o: 0, r: 0, c: 0 },
  { id: 28, o: 0, r: 0, c: 2 },
  { id: 20, o: 0, r: 0, c: 4 },
  { id: 0, o: 1, r: 0, c: 5 },
  { id: 19, o: 0, r: 1, c: 0 },
  { id: 17, o: 0, r: 2, c: 3 },
  { id: 26, o: 3, r: 3, c: 1 },
  { id: 18, o: 4, r: 3, c: 4 },
  { id: 2, o: 0, r: 5, c: 0 },
];
const LOGO_BUTTON_INDEX = 4;

/** Логотип-нашивка: то же лоскутное полотно, что на иконке игры —
 *  тетромино-фигурки игры без дыр + пуговица, как на обложке Patchwork */
function LogoMark({ size = 92 }: { size?: number }) {
  const INSET = 0.06;
  const sc = 1 - INSET * 2;
  return (
    <svg width={size} height={size} viewBox="-0.26 -0.26 6.52 6.52" aria-hidden>
      {/* фон-лён + рама */}
      <rect x="-0.26" y="-0.26" width="6.52" height="6.52" rx="0.72" fill="#F3E9D2" />
      <rect x="-0.14" y="-0.14" width="6.28" height="6.28" rx="0.6" fill="none" stroke="#8B5E3C" strokeWidth="0.17" />
      <rect
        x="-0.03"
        y="-0.03"
        width="6.06"
        height="6.06"
        rx="0.3"
        fill="none"
        stroke="#8B5E3C"
        strokeWidth="0.07"
        strokeDasharray="0.3 0.2"
        opacity="0.6"
      />
      {LOGO_PACK.map((p, i) => {
        const o = orientationsFor(p.id)[p.o];
        const tr = `translate(${o.w / 2} ${o.h / 2}) scale(${sc}) translate(${-o.w / 2} ${-o.h / 2})`;
        const btnCell = i === LOGO_BUTTON_INDEX ? orientationCells(p.id, p.o)[1] : null;
        return (
          <g key={i} transform={`translate(${p.c} ${p.r})`}>
            <g transform={tr}>
              <PatchGlyph patchId={p.id} orientation={p.o} cell={1} income={false} />
            </g>
            {btnCell && (
              <g transform={`translate(${btnCell[1] + 0.5} ${btnCell[0] + 0.5}) scale(0.62)`}>
                <circle r={0.46} cy={0.06} fill="#2E1D0E" opacity="0.25" />
                <circle r={0.42} fill="#F8F0DD" stroke="#5B3B20" strokeWidth={0.1} />
                <circle r={0.29} fill="none" stroke="#C9B583" strokeWidth={0.055} />
                <circle r={0.095} cx={-0.125} cy={-0.125} fill="#5B3B20" />
                <circle r={0.095} cx={0.125} cy={-0.125} fill="#5B3B20" />
                <circle r={0.095} cx={-0.125} cy={0.125} fill="#5B3B20" />
                <circle r={0.095} cx={0.125} cy={0.125} fill="#5B3B20" />
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
}

export interface HomeScreenProps {
  onStart: (level: BotLevel) => void;
  onDaily: () => void;
  onResume: (state: GameState) => void;
  onOpenRules: () => void;
  onOnline: () => void;
  onQuickOnline: () => void;
  /** живая онлайн-сессия (чтобы не предлагать свою же комнату в баннере) */
  session?: MpSession | null;
  /** вход в комнату из меню: баннер «ждёт игру» / приглашение друга */
  onJoinRoom?: (s: MpSession, role: 'host' | 'guest') => void;
}

/** Декоративная сцена-фон меню: тёплый свет сверху, «пушинки» в луче,
 *  большое лоскутное полотно у нижней кромки (как будто стол со стёганым
 *  одеялом). Всё pointer-events:none, только атмосфера. */
function MenuScene() {
  const lints = [
    { left: '12%', top: '26%', dur: '13s', delay: '0s', size: 5 },
    { left: '38%', top: '52%', dur: '17s', delay: '-4s', size: 4 },
    { left: '64%', top: '18%', dur: '11s', delay: '-2s', size: 6 },
    { left: '82%', top: '44%', dur: '15s', delay: '-7s', size: 4 },
    { left: '26%', top: '70%', dur: '19s', delay: '-9s', size: 5 },
    { left: '52%', top: '82%', dur: '12s', delay: '-5s', size: 3 },
  ];
  return (
    <div className="menu-scene" aria-hidden>
      <div className="menu-scene-light" />
      {/* стёганое «одеяло» у нижней кромки */}
      <div className="absolute inset-x-0 bottom-0 h-[240px]">
        <BigBackdropPatch id={24} className="-left-14 bottom-[-70px] h-[190px] w-[190px]" rotate={-12} />
        <BigBackdropPatch id={31} className="left-[16%] bottom-[-96px] h-[168px] w-[168px]" rotate={7} />
        <BigBackdropPatch id={9} className="left-[42%] bottom-[-80px] h-[210px] w-[210px]" rotate={-6} />
        <BigBackdropPatch id={21} className="left-[68%] bottom-[-104px] h-[176px] w-[176px]" rotate={11} />
        <BigBackdropPatch id={32} className="-right-12 bottom-[-76px] h-[200px] w-[200px]" rotate={-9} />
      </div>
      {/* пушинки в луче света */}
      {lints.map((l, i) => (
        <span
          key={i}
          className="lint"
          style={{
            left: l.left,
            top: l.top,
            width: l.size,
            height: l.size,
            animationDuration: l.dur,
            animationDelay: l.delay,
          }}
        />
      ))}
    </div>
  );
}

function BigBackdropPatch({ id, className, rotate }: { id: number; className: string; rotate: number }) {
  const patch = PATCHES[id];
  const maxR = Math.max(...patch.cells.map((c) => c[0])) + 1;
  const maxC = Math.max(...patch.cells.map((c) => c[1])) + 1;
  const dim = Math.max(maxR, maxC);
  return (
    <svg
      viewBox={`-0.3 -0.3 ${dim + 0.6} ${dim + 0.6}`}
      preserveAspectRatio="xMidYMid meet"
      className={`absolute ${className}`}
      style={{ transform: `rotate(${rotate}deg)`, opacity: 0.16 }}
    >
      <GlyphDirect patchId={id} />
    </svg>
  );
}

/** Верёвка с мини-лоскутками на прищепках — качается от «сквозняка» */
function Clothesline() {
  return (
    <svg viewBox="0 0 360 86" className="pointer-events-none absolute -top-6 left-1/2 h-[86px] w-[360px] max-w-full -translate-x-1/2" aria-hidden>
      {/* верёвка */}
      <path
        d="M0 14 C 90 30, 270 30, 360 14"
        fill="none"
        stroke="#B99B6B"
        strokeWidth="2.2"
        strokeLinecap="round"
        opacity="0.8"
      />
      <HangingPatch id={12} x={62} y={21} dur="4.6s" delay="-0.8s" w={30} />
      <HangingPatch id={5} x={175} y={27} dur="5.3s" delay="-2.1s" w={34} />
      <HangingPatch id={27} x={288} y={21} dur="4.9s" delay="-1.4s" w={28} />
    </svg>
  );
}

function HangingPatch({
  id,
  x,
  y,
  dur,
  delay,
  w,
}: {
  id: number;
  x: number;
  y: number;
  dur: string;
  delay: string;
  w: number;
}) {
  const patch = PATCHES[id];
  const maxR = Math.max(...patch.cells.map((c) => c[0])) + 1;
  const maxC = Math.max(...patch.cells.map((c) => c[1])) + 1;
  const dim = Math.max(maxR, maxC);
  const h = Math.round((w * (maxR + 0.4)) / dim);
  return (
    <g className="sway" style={{ transformOrigin: `${x}px ${y}px`, animationDuration: dur, animationDelay: delay }}>
      {/* прищепка */}
      <rect x={x - 4} y={y - 9} width={8} height={13} rx={1.5} fill="#C8915B" stroke="#8A5E2F" strokeWidth={1.4} />
      {/* лоскуток */}
      <svg x={x - w / 2} y={y + 3} width={w} height={h} viewBox={`-0.3 -0.3 ${dim + 0.6} ${dim + 0.6}`} style={{ overflow: 'visible' }}>
        <GlyphDirect patchId={id} />
      </svg>
    </g>
  );
}

/** Бегущая стёжка под заголовком — «иголка шьёт прямо сейчас» */
function NeedleLine() {
  return (
    <svg viewBox="0 0 220 14" className="mt-1 h-[13px] w-[190px] max-w-[56vw]" aria-hidden>
      <path
        d="M6 7 C 60 3, 160 11, 214 6"
        fill="none"
        stroke="#C0603A"
        strokeWidth="2.2"
        strokeLinecap="round"
        className="needle-run"
      />
      {/* иголка на конце стёжки */}
      <g>
        <rect x={210} y={4.2} width={4.2} height={5.6} rx={1} fill="#B9BCC1" stroke="#7E8288" strokeWidth={0.8} />
        <rect x={212.2} y={5.6} width={1.5} height={2.8} rx={0.8} fill="#5B6167" />
      </g>
    </svg>
  );
}

export function HomeScreen({
  onStart,
  onDaily,
  onResume,
  onOpenRules,
  onOnline,
  onQuickOnline,
  session,
  onJoinRoom,
}: HomeScreenProps) {
  const { toast } = useToast();
  const lang = useLang();
  // заголовок вкладки — на языке интерфейса («Лоскутки» / «Patchwork»)
  useDocumentTitle();
  const [pickOpen, setPickOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [friendsOpen, setFriendsOpen] = useState(false);
  const [busyRoom, setBusyRoom] = useState(false);

  const store = useSyncExternalStore(subscribeStore, getStoreSnapshot, getStoreServerSnapshot);
  const online = useOnline();
  const fr = useFriends();

  const s = store.stats;
  const daily = store.daily[todayKey()];
  const resumeGame = store.currentGame ?? null;

  // ===== ОТКРЫТЫЕ КОМНАТЫ внизу главного меню (обновление живьём) =====
  const [rooms, setRooms] = useState<OpenRoomInfo[] | null>(null);
  useEffect(() => {
    if (!online) {
      setRooms(null);
      return;
    }
    if (mpWsEnabled()) {
      // WS-режим: сервер сам рассылает список открытых комнат каждые ~3с
      return mpOnRooms((list) => setRooms(list ?? []));
    }
    let stop = false;
    let timer: ReturnType<typeof setTimeout>;
    const refresh = async () => {
      const list = await mpListRooms();
      if (stop) return;
      setRooms(list);
      timer = setTimeout(refresh, 6000);
    };
    void refresh();
    return () => {
      stop = true;
      clearTimeout(timer);
    };
  }, [online]);

  const myUid = useMemo(() => loadProfileForJoin().uid, []);
  /** чужие комнаты (свою прячем — входить «сам к себе» нельзя) */
  const openRooms = useMemo(
    () => (rooms ?? []).filter((r) => r.code !== session?.code && (!myUid || r.hostUid !== myUid)),
    [rooms, session?.code, myUid],
  );

  const joinWaiter = async (roomCode: string) => {
    if (busyRoom) return;
    setBusyRoom(true);
    sound.ensure();
    sound.tap();
    try {
      const p = loadProfileForJoin();
      const { code, playerId } = await mpJoin({
        code: roomCode,
        name: p.name,
        avatar: p.avatar,
        uid: p.uid,
      });
      const s2: MpSession = { playerId, code, name: p.name, avatar: p.avatar };
      onJoinRoom?.(s2, 'guest');
    } catch (e) {
      toast({ title: t(mpErrorKeyJoin((e as { code?: string })?.code ?? '')) });
    } finally {
      setBusyRoom(false);
    }
  };

  const frBadge =
    fr.friends.reduce((n, f) => n + f.unread, 0) + fr.requests.length + fr.invites.length;

  return (
    <div className="relative mx-auto flex min-h-svh w-full max-w-[520px] flex-col items-center px-4 pb-[max(env(safe-area-inset-bottom),8px)] pt-[max(env(safe-area-inset-top),10px)] md:max-w-[880px] md:px-8">
      {/* живая сцена-фон */}
      <MenuScene />

      {/* небольшая отдельная кнопка «Друзья» с индикацией событий.
          Значок — «человек с плюсом»: сердечко было непонятно */}
      <button
        type="button"
        onClick={() => {
          sound.ensure();
          sound.tap();
          setFriendsOpen(true);
        }}
        className={`btn-cloth absolute right-4 top-[max(env(safe-area-inset-top),12px)] z-20 flex h-11 w-11 items-center justify-center rounded-2xl md:right-8 ${
          online && fr.available ? '' : 'opacity-60'
        }`}
        aria-label={t('fr_title')}
      >
        <UserRoundPlus className={`h-5.5 w-5.5 ${frBadge > 0 ? 'text-[#C33A2F]' : 'text-primary'}`} />
        {frBadge > 0 && (
          <span className="pop-in absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full border-2 border-card bg-[#C33A2F] px-1 text-[10.5px] font-extrabold text-white">
            {frBadge > 99 ? '99+' : frBadge}
          </span>
        )}
      </button>

      {/* шапка: верёвка + логотип + заголовок (крупно — «жилое» меню) */}
      <div className="relative z-10 flex w-full flex-col items-center">
        <Clothesline />
        <div className="logo-float pop-in relative">
          <LogoMark size={92} />
        </div>
        <h1
          className="font-display title-stitch mt-2 text-[40px] leading-none text-foreground md:text-[46px]"
          style={{ letterSpacing: '0.04em' }}
        >
          {t('app_title')}
        </h1>
        <NeedleLine />
        <p className="mt-1 text-[13.5px] font-bold tracking-wide text-muted-foreground md:text-[14.5px]">
          {t('app_subtitle')}
        </p>
      </div>

      <div className="stitch-divider my-2.5 w-full max-w-[300px]" />

      {/* Продолжить партию — меню не должно прокручиваться даже с ней */}
      {resumeGame && resumeGame.phase !== 'gameover' && (
        <button
          type="button"
          onClick={() => {
            sound.ensure();
            sound.tap();
            onResume(resumeGame);
          }}
          className="stitched-card mb-2 flex w-full items-center gap-2.5 p-2 text-left transition-transform hover:-translate-y-0.5 active:translate-y-0"
        >
          <div className="w-[42px] shrink-0">
            <MiniQuilt board={resumeGame.players[0].board} className="w-full rounded-md border border-border" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[14px] font-extrabold text-foreground">{t('home_resume')}</div>
            <div className="truncate text-[11.5px] font-semibold text-muted-foreground">
              {t('home_resume_vs', { name: personaName(lang, resumeGame.botLevel), n: resumeGame.turn + 1 })}
            </div>
          </div>
          <RotateCcw className="h-4.5 w-4.5 shrink-0 text-primary" />
        </button>
      )}

      {/* Основные кнопки: крупно, на планшете — карточки в ряд */}
      <div className="relative z-10 w-full space-y-2.5 md:grid md:grid-cols-3 md:items-stretch md:gap-3 md:space-y-0">
        <Button
          size="lg"
          className="btn-wood h-14 w-full rounded-2xl text-[17px] font-extrabold md:col-span-3 md:h-auto md:min-h-[64px] md:text-[18px]"
          onClick={() => {
            sound.ensure();
            sound.tap();
            setPickOpen(true);
          }}
        >
          <Play className="mr-2 h-5.5 w-5.5" />
          {t('home_play')}
        </Button>

        {/* Быстрая игра — сетевой режим с автопоиском соперника */}
        <button
          type="button"
          onClick={() => {
            if (!online) {
              toast({ title: t('mp_offline_t'), description: t('mp_offline_d') });
              return;
            }
            sound.ensure();
            sound.tap();
            onQuickOnline();
          }}
          className={`flex w-full items-center gap-3 rounded-2xl border-2 p-3 text-left transition-all hover:-translate-y-0.5 active:translate-y-0 ${
            online
              ? 'border-[#8AA06F]/60 bg-[#8AA06F]/12 shadow-[inset_0_2px_0_rgba(255,255,255,.6),0_6px_14px_-8px_rgba(70,100,40,.45)]'
              : 'border-border bg-muted/60 opacity-80'
          }`}
        >
          <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#8AA06F]/30">
            <Zap className="h-6.5 w-6.5 text-[#4e6437]" fill="#cfe0b4" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-[15.5px] font-extrabold text-foreground">
              {t('home_quick')}
              {online ? (
                <span className="flex shrink-0 items-center gap-1">
                  <span className="dot-online" />
                </span>
              ) : (
                <span className="shrink-0 rounded-full bg-muted px-2 py-0.5 text-[9.5px] font-extrabold text-muted-foreground">
                  {t('home_quick_off')}
                </span>
              )}
            </div>
            <div className="truncate text-[12px] font-semibold text-muted-foreground">{t('home_quick_h')}</div>
          </div>
        </button>

        {/* С другом — онлайн по коду или через открытую комнату */}
        <button
          type="button"
          onClick={() => {
            if (!online) {
              toast({ title: t('mp_offline_t'), description: t('mp_offline_d') });
              return;
            }
            sound.ensure();
            sound.tap();
            onOnline();
          }}
          className="flex w-full items-center gap-3 rounded-2xl border-2 border-[#5B7E9E]/55 bg-[#5B7E9E]/12 p-3 text-left shadow-[inset_0_2px_0_rgba(255,255,255,.6),0_6px_14px_-8px_rgba(50,70,100,.45)] transition-all hover:-translate-y-0.5 active:translate-y-0"
        >
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#5B7E9E]/25">
            <Users className="h-6.5 w-6.5 text-[#3D5A77]" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[15.5px] font-extrabold text-foreground">{t('mp_title')}</div>
            <div className="truncate text-[12px] font-semibold text-muted-foreground">{t('mp_desc')}</div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => {
            sound.ensure();
            sound.tap();
            if (daily) {
              toast({
                title: t('home_daily_done_t'),
                description: t('home_daily_done_d', {
                  res: daily.won ? t('win') : t('loss'),
                  score: `${daily.score > 0 ? '+' : ''}${daily.score}`,
                }),
              });
              return;
            }
            onDaily();
          }}
          className={`flex w-full items-center gap-3 rounded-2xl border-2 p-3 text-left transition-all hover:-translate-y-0.5 active:translate-y-0 ${
            daily
              ? 'border-border bg-muted/60 opacity-80'
              : 'border-[#D9A13F]/60 bg-[#D9A13F]/12 shadow-[inset_0_2px_0_rgba(255,255,255,.6),0_6px_14px_-8px_rgba(120,80,20,.45)]'
          }`}
        >
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#D9A13F]/25">
            <CalendarDays className="h-6.5 w-6.5 text-[#A6721F]" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-[15.5px] font-extrabold text-foreground">
              {t('home_daily', { n: dailyNumber(new Date()) })}
              <Sparkles className="h-3.5 w-3.5 text-[#A6721F]" />
            </div>
            <div className="truncate text-[11.5px] font-semibold text-muted-foreground">
              {daily
                ? t('home_daily_played', {
                    res: daily.won ? t('win') : t('loss'),
                    score: `${daily.score > 0 ? '+' : ''}${daily.score}`,
                  })
                : t('home_daily_desc', { name: personaName(lang, 'fedor') })}
            </div>
          </div>
        </button>
      </div>

      <div className="min-h-2 flex-1" />

      {/* ОТКРЫТЫЕ КОМНАТЫ — прямо в главном меню (снизу): подсвечены,
          вход одним тапом; свою комнату не показываем («сам к себе» нельзя) */}
      {online && (
        <div className="relative z-10 mb-2 w-full">
          <div className="mb-1.5 flex items-center gap-2 px-0.5">
            <Users className="h-4 w-4 shrink-0 text-primary" />
            <div className="text-[12.5px] font-extrabold uppercase tracking-wide text-foreground">
              {t('home_rooms_title')}
            </div>
            {openRooms.length > 0 && (
              <span className="pop-in flex shrink-0 items-center gap-1 rounded-full bg-[#8AA06F]/20 px-2 py-0.5 text-[10.5px] font-extrabold text-[#4e6437]">
                <span className="dot-online" />
                {openRooms.length}
              </span>
            )}
          </div>
          {openRooms.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border bg-muted/30 px-3 py-2 text-center text-[12px] font-bold text-muted-foreground">
              {t('mp_none')}
            </div>
          ) : (
            <div className="nice-scroll max-h-[152px] space-y-1.5 overflow-y-auto pb-1">
              {openRooms.map((r) => (
                <button
                  key={r.code}
                  type="button"
                  disabled={busyRoom}
                  onClick={() => void joinWaiter(r.code)}
                  className="pop-in flex w-full items-center gap-2.5 rounded-2xl border-2 border-[#8AA06F]/60 bg-[#8AA06F]/10 p-2 text-left shadow-[inset_0_2px_0_rgba(255,255,255,.55),0_5px_12px_-8px_rgba(70,100,40,.5)] transition-all hover:-translate-y-0.5 active:translate-y-0"
                >
                  <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#8AA06F]/25">
                    <Portrait src={avatarUrl(r.hostAvatar)} size={32} alt={r.hostName} />
                    {r.quick && (
                      <span className="absolute -right-1 -top-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-[#8AA06F] text-white">
                        <Zap className="h-2.5 w-2.5" fill="#fff" />
                      </span>
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-[14px] font-extrabold text-foreground">{r.hostName}</span>
                      <span className="dot-online shrink-0" />
                    </span>
                    <span className="block truncate text-[11px] font-bold text-muted-foreground">
                      {r.quick ? t('mp_room_quick') : t('home_waiting', { name: r.hostName })}
                    </span>
                  </span>
                  <span className="btn-wood flex h-9 shrink-0 items-center rounded-xl px-3.5 text-[13px] font-extrabold text-white">
                    {t('home_rooms_join')}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Нижний ряд */}
      <div className="relative z-10 grid w-full grid-cols-3 gap-2.5">
        <MenuTile icon={<BookOpen className="h-5.5 w-5.5" />} label={t('home_rules')} onClick={onOpenRules} />
        <MenuTile
          icon={<BarChart3 className="h-5.5 w-5.5" />}
          label={t('home_stats')}
          badge={s ? (s.games > 0 ? `${s.wins}${t('win')[0].toUpperCase()}` : undefined) : undefined}
          onClick={() => {
            sound.tap();
            setStatsOpen(true);
          }}
        />
        <MenuTile
          icon={<Settings2 className="h-5.5 w-5.5" />}
          label={t('home_settings')}
          onClick={() => {
            sound.tap();
            setSettingsOpen(true);
          }}
        />
      </div>

      {/* ===== Выбор соперника ===== */}
      <Dialog open={pickOpen} onOpenChange={setPickOpen}>
        <DialogContent aria-describedby={undefined} className="w-[min(94vw,440px)]">
          <DialogHeader>
            <DialogTitle className="font-display text-[22px]">{t('pick_title')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-2.5">
            {(Object.keys(BOT_PERSONAS) as BotLevel[]).map((lvl) => {
              const p = BOT_PERSONAS[lvl];
              const stat = s?.byLevel[lvl];
              return (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => {
                    sound.tap();
                    setPickOpen(false);
                    onStart(lvl);
                  }}
                  className="stitched-card flex w-full items-center gap-3 p-3 text-left transition-transform hover:-translate-y-0.5 active:translate-y-0"
                >
                  <BotAvatar level={lvl} size={62} />
                  <div className="min-w-0 flex-1">
                    <div className="text-[16.5px] font-extrabold text-foreground">{personaName(lang, lvl)}</div>
                    <div className="text-[12.5px] font-semibold text-muted-foreground">{personaTitle(lang, lvl)}</div>
                    {stat && stat.games > 0 && (
                      <div className="mt-0.5 text-[12px] font-bold text-primary">
                        {t('pick_wins', {
                          w: stat.wins,
                          g: stat.games,
                          p: Math.round((stat.wins / stat.games) * 100),
                        })}
                      </div>
                    )}
                  </div>
                  <span
                    className={`shrink-0 rounded-full px-2.5 py-1 text-[12px] font-extrabold ${
                      lvl === 'glasha'
                        ? 'bg-[#8AA06F]/25 text-[#4e6437]'
                        : lvl === 'fedor'
                          ? 'bg-[#D9A13F]/25 text-[#8A5E13]'
                          : 'bg-[#8E5A79]/25 text-[#6E3B5E]'
                    }`}
                  >
                    {personaDifficulty(lang, lvl)}
                  </span>
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Статистика ===== */}
      <StatsDialog open={statsOpen} onOpenChange={setStatsOpen} store={store} />

      {/* ===== Настройки ===== */}
      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />

      {/* ===== Друзья ===== */}
      <FriendsDialog
        open={friendsOpen}
        onOpenChange={setFriendsOpen}
        onJoinRoom={(j, role) => {
          const s2: MpSession = { playerId: j.playerId, code: j.code, name: j.name, avatar: j.avatar, isPublic: j.isPublic, invite: j.invite };
          onJoinRoom?.(s2, role);
        }}
      />
    </div>
  );
}

/** профиль для входа в комнату из баннера ожидания */
function loadProfileForJoin(): { name: string; avatar: string; uid: string } {
  try {
    const raw = localStorage.getItem('loskutki.mp.profile.v1');
    if (raw) {
      const p = JSON.parse(raw) as { name?: string; avatar?: string; uid?: string };
      if (typeof p.name === 'string' && p.name.trim()) {
        return { name: p.name.trim().slice(0, 16), avatar: p.avatar ?? 'ann', uid: p.uid ?? '' };
      }
    }
  } catch { /* ignore */ }
  return { name: '', avatar: 'ann', uid: '' };
}

function mpErrorKeyJoin(code: string): string {
  switch (code) {
    case 'notfound': return 'mp_notfound';
    case 'full': return 'mp_full';
    case 'started': return 'mp_started';
    case 'ownroom': return 'mp_own_room';
    default: return 'mp_net';
  }
}

function MenuTile({
  icon,
  label,
  onClick,
  badge,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  badge?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="stitched-card flex flex-col items-center gap-1 px-2 py-2.5 transition-transform hover:-translate-y-0.5 active:translate-y-0"
    >
      <div className="relative text-primary">
        {icon}
        {badge && (
          <span className="absolute -top-2 -right-6 rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-extrabold text-primary-foreground">
            {badge}
          </span>
        )}
      </div>
      <span className="text-[12px] font-extrabold text-foreground">{label}</span>
    </button>
  );
}

function StatsDialog({
  open,
  onOpenChange,
  store,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  store: StatsStore;
}) {
  const lang = useLang();
  const [achOpen, setAchOpen] = useState<string | null>(null);
  const s = store.stats;
  const winrate = s.games > 0 ? Math.round((s.wins / s.games) * 100) : 0;
  const avgCov = s.games > 0 ? Math.round(s.totalCoverage / s.games) : 0;
  const dailyKeys = Object.keys(store.daily).sort().reverse().slice(0, 14);
  const locale = lang === 'en' ? 'en-US' : 'ru-RU';
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent aria-describedby={undefined} className="max-h-[88svh] w-[min(94vw,520px)] overflow-y-auto nice-scroll">
        <DialogHeader>
          <DialogTitle className="font-display text-[22px]">{t('stats_title')}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-2">
          <BigStat value={s.games} label={t('stats_games')} />
          <BigStat value={`${winrate}%`} label={t('stats_wr')} />
          <BigStat value={s.bestScore > -1000 ? s.bestScore : '—'} label={t('stats_best')} />
          <BigStat value={s.bestStreak} label={t('stats_streak')} />
          <BigStat value={`${avgCov}/81`} label={t('stats_avg_cov')} />
          <BigStat value={s.bestCoverage} label={t('stats_max_cov')} />
          <BigStat value={s.wins} label={t('stats_wins_total')} />
          <BigStat value={s.leatherMax} label={t('stats_leather')} />
        </div>
        <div className="stitch-divider my-2" />
        <h3 className="font-display text-[18px]">{t('stats_ach')}</h3>
        <div className="grid grid-cols-2 gap-2">
          {ACHIEVEMENTS.map((a) => {
            const got = !!store.achievements[a.id];
            return (
              <button
                key={a.id}
                type="button"
                onClick={() => setAchOpen(a.id)}
                className={`flex items-center gap-2 rounded-xl border p-2.5 text-left transition-transform active:scale-[0.98] ${
                  got ? 'border-[#D9A13F]/60 bg-[#D9A13F]/10' : 'border-border bg-muted/40'
                }`}
              >
                <span className="text-[22px] leading-none" style={{ filter: got ? undefined : 'grayscale(1) opacity(0.55)' }}>
                  {a.icon}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-extrabold text-foreground">
                    {achTitle(lang, a.id)}
                  </span>
                  <span className="block text-[11px] font-semibold text-muted-foreground">
                    {got ? '✓' : '🔒'}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
        {dailyKeys.length > 0 && (
          <>
            <div className="stitch-divider my-2" />
            <h3 className="font-display text-[18px]">{t('stats_daily')}</h3>
            <div className="space-y-1">
              {dailyKeys.map((k) => {
                const d = store.daily[k];
                return (
                  <div key={k} className="flex items-center justify-between rounded-lg bg-muted/50 px-3 py-1.5 text-[13px] font-bold">
                    <span>{k}</span>
                    <span className={d.won ? 'text-primary' : 'text-destructive'}>
                      {d.won ? t('win') : t('loss')} · {d.score > 0 ? '+' : ''}
                      {d.score}
                    </span>
                  </div>
                );
              })}
            </div>
          </>
        )}
        {/* друзья — личный счёт онлайн-партий */}
        {Object.keys(store.friendStats).length > 0 && (
          <>
            <div className="stitch-divider my-2" />
            <h3 className="font-display text-[18px]">{t('stats_friends')}</h3>
            <div className="space-y-1">
              {Object.values(store.friendStats)
                .sort((a, b) => b.games - a.games)
                .slice(0, 20)
                .map((fs) => (
                  <div key={fs.name + fs.lastAt} className="flex items-center gap-2 rounded-lg bg-muted/50 px-2.5 py-1.5">
                    <img src={avatarUrl(fs.avatar)} alt={fs.name} className="h-7 w-7 rounded-full border border-border object-cover" />
                    <span className="min-w-0 flex-1 truncate text-[13px] font-extrabold">{fs.name}</span>
                    <span className="shrink-0 text-[12px] font-bold text-muted-foreground">
                      {t('fr_vs', { g: fs.games, w: fs.wins })}
                    </span>
                  </div>
                ))}
            </div>
          </>
        )}
        {/* полное описание достижения по тапу */}
        <Dialog open={achOpen !== null} onOpenChange={(v) => { if (!v) setAchOpen(null); }}>
          {achOpen !== null && (
            <DialogContent aria-describedby={undefined} className="w-[min(88vw,380px)]">
              <DialogHeader>
                <DialogTitle className="font-display text-center text-[21px]">
                  {achTitle(lang, achOpen)}
                </DialogTitle>
              </DialogHeader>
              <div className="flex flex-col items-center gap-3 px-2 pb-1">
                <span
                  className="text-[46px] leading-none"
                  style={{
                    filter: store.achievements[achOpen] ? undefined : 'grayscale(1) opacity(0.5)',
                  }}
                >
                  {ACHIEVEMENTS.find((a) => a.id === achOpen)?.icon}
                </span>
                <p className="text-center text-[14px] font-semibold text-foreground">
                  {achDesc(lang, achOpen)}
                </p>
                {store.achievements[achOpen] ? (
                  <span className="rounded-full bg-[#D9A13F]/15 px-3 py-1.5 text-[12px] font-extrabold text-[#8A5E13]">
                    {t('ach_unlocked_at', {
                      d: new Date(store.achievements[achOpen]).toLocaleDateString(locale, {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      }),
                    })}
                  </span>
                ) : (
                  <span className="rounded-full bg-muted px-3 py-1.5 text-[12px] font-extrabold text-muted-foreground">
                    {t('ach_locked')}
                  </span>
                )}
              </div>
            </DialogContent>
          )}
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}

function BigStat({ value, label }: { value: React.ReactNode; label: string }) {
  return (
    <div className="stitched-card flex flex-col items-center px-2 py-2.5">
      <span className="text-[20px] font-extrabold text-foreground">{value}</span>
      <span className="text-[10.5px] font-bold tracking-wide text-muted-foreground uppercase">{label}</span>
    </div>
  );
}

function SettingsDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { toast } = useToast();
  const lang = useLang();
  const [st, setSt] = useState(() => loadStore().settings);
  /** подтверждение сброса — в стиле игры (не браузерный confirm) */
  const [resetAsk, setResetAsk] = useState(false);
  /** мой постоянный ID — виден всегда, никогда не меняется */
  const myUid = useMemo(() => formatFriendCode(loadProfileForJoin().uid), []);
  const save = (patch: Partial<typeof st>) => {
    const next = { ...st, ...patch };
    setSt(next);
    const store = loadStore();
    store.settings = next;
    saveStore(store);
    sound.enabled = next.sound;
  };
  const setLang = (l: Lang) => {
    if (l === lang) return;
    sound.ensure();
    sound.tap();
    save({ lang: l });
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent aria-describedby={undefined} className="w-[min(94vw,420px)]">
        <DialogHeader>
          <DialogTitle className="font-display text-[22px]">{t('set_title')}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <SettingRow
            label={t('set_sound')}
            hint={t('set_sound_h')}
            checked={st.sound}
            onChange={(v) => {
              save({ sound: v });
              if (v) {
                sound.ensure();
                sound.income();
              }
            }}
          />
          <SettingRow
            label={t('set_vibro')}
            hint={t('set_vibro_h')}
            checked={st.vibration}
            onChange={(v) => save({ vibration: v })}
          />
          <SettingRow
            label={t('set_grid')}
            hint={t('set_grid_h')}
            checked={st.hints}
            onChange={(v) => save({ hints: v })}
          />
          {/* Язык: русский (по умолчанию) / английский */}
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-[15.5px] font-extrabold">{t('set_lang')}</div>
              <div className="text-[12.5px] font-semibold text-muted-foreground">{t('set_lang_h')}</div>
            </div>
            <div className="flex overflow-hidden rounded-xl border-2 border-border shadow-sm">
              <button
                type="button"
                onClick={() => setLang('ru')}
                aria-pressed={lang === 'ru'}
                className={`px-3 py-2 text-[13px] font-extrabold transition-colors ${
                  lang === 'ru' ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground/70 hover:bg-muted'
                }`}
              >
                Русский
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                aria-pressed={lang === 'en'}
                className={`px-3 py-2 text-[13px] font-extrabold transition-colors ${
                  lang === 'en' ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground/70 hover:bg-muted'
                }`}
              >
                English
              </button>
            </div>
          </div>
          {/* мой постоянный ID для друзей — никогда не меняется
              (сброс прогресса его НЕ трогает) */}
          <div className="flex items-center justify-between gap-3 rounded-xl border-2 border-border bg-card/60 p-2.5">
            <div className="min-w-0">
              <div className="text-[14px] font-extrabold">{t('set_my_id')}</div>
              <div className="text-[11.5px] font-semibold text-muted-foreground">{t('set_my_id_h')}</div>
            </div>
            <div
              className="shrink-0 font-display text-[19px] leading-none tracking-[0.12em] text-foreground"
              style={{ textShadow: '0 2px 0 rgba(169,133,90,.25)' }}
            >
              {myUid}
            </div>
          </div>
          <div className="stitch-divider my-1" />
          <button
            type="button"
            className="w-full rounded-xl border-2 border-destructive/40 bg-destructive/8 py-2.5 text-[14.5px] font-extrabold text-destructive"
            onClick={() => {
              sound.tap();
              setResetAsk(true);
            }}
          >
            {t('set_reset')}
          </button>
          {/* подтверждение сброса — в стиле игры */}
          <ConfirmDialog
            open={resetAsk}
            title={t('set_reset_confirm')}
            confirmText={t('set_reset_yes')}
            cancelText={t('c_cancel')}
            trash
            onConfirm={() => {
              setResetAsk(false);
              localStorage.removeItem('loskutki.v1');
              sound.enabled = true;
              setSt(loadStore().settings);
              toast({ title: t('set_reset_done'), description: t('set_reset_done_h') });
            }}
            onCancel={() => setResetAsk(false)}
          />
          {/* политика конфиденциальности — ссылка для Google Play, открывается
              в новой вкладке и работает даже без установленной игры */}
          <a
            href="/privacy"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-border bg-card py-2.5 text-[14px] font-extrabold text-foreground/75 transition-colors hover:bg-muted"
          >
            <ShieldCheck className="h-4 w-4 text-[#7A8B5A]" />
            {t('set_privacy')}
          </a>
          {/* версия сборки — перенесена из футера меню по просьбе пользователя */}
          <div className="pt-1 text-center text-[11px] font-extrabold tracking-wide text-muted-foreground/80">
            {t('set_version', { v: APP_VERSION })}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function SettingRow({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div>
        <div className="text-[15.5px] font-extrabold">{label}</div>
        <div className="text-[12.5px] font-semibold text-muted-foreground">{hint}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
